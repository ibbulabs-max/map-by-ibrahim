export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "14.15"
  }
  public: {
    Tables: {
      activity_logs: {
        Row: {
          action: string
          created_at: string
          details: Json | null
          id: string
          user_id: string | null
          username: string | null
        }
        Insert: {
          action: string
          created_at?: string
          details?: Json | null
          id?: string
          user_id?: string | null
          username?: string | null
        }
        Update: {
          action?: string
          created_at?: string
          details?: Json | null
          id?: string
          user_id?: string | null
          username?: string | null
        }
        Relationships: []
      }
      house_members: {
        Row: {
          created_at: string
          data: Json
          house_uuid: string
          id: string
          member_id: string | null
          member_name: string | null
          possible_duplicate: boolean
          source_files: Json
          updated_at: string
          uploaded_at: string | null
          uploaded_by: string | null
        }
        Insert: {
          created_at?: string
          data?: Json
          house_uuid: string
          id?: string
          member_id?: string | null
          member_name?: string | null
          possible_duplicate?: boolean
          source_files?: Json
          updated_at?: string
          uploaded_at?: string | null
          uploaded_by?: string | null
        }
        Update: {
          created_at?: string
          data?: Json
          house_uuid?: string
          id?: string
          member_id?: string | null
          member_name?: string | null
          possible_duplicate?: boolean
          source_files?: Json
          updated_at?: string
          uploaded_at?: string | null
          uploaded_by?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "house_members_house_uuid_fkey"
            columns: ["house_uuid"]
            isOneToOne: false
            referencedRelation: "houses"
            referencedColumns: ["id"]
          },
        ]
      }
      houses: {
        Row: {
          accuracy: number | null
          assigned_csw_id: string | null
          created_at: string
          created_by: string | null
          custom_type: string | null
          data: Json
          house_id: string
          house_number: string | null
          id: string
          latitude: number | null
          location_source: string | null
          location_status: string
          longitude: number | null
          mapped_at: string | null
          mapped_by: string | null
          pin_id: string | null
          pin_type: string
          source_files: Json
          status: string | null
          supervisor_id: string | null
          updated_at: string
          uploaded_at: string | null
          uploaded_by: string | null
        }
        Insert: {
          accuracy?: number | null
          assigned_csw_id?: string | null
          created_at?: string
          created_by?: string | null
          custom_type?: string | null
          data?: Json
          house_id: string
          house_number?: string | null
          id?: string
          latitude?: number | null
          location_source?: string | null
          location_status?: string
          longitude?: number | null
          mapped_at?: string | null
          mapped_by?: string | null
          pin_id?: string | null
          pin_type?: string
          source_files?: Json
          status?: string | null
          supervisor_id?: string | null
          updated_at?: string
          uploaded_at?: string | null
          uploaded_by?: string | null
        }
        Update: {
          accuracy?: number | null
          assigned_csw_id?: string | null
          created_at?: string
          created_by?: string | null
          custom_type?: string | null
          data?: Json
          house_id?: string
          house_number?: string | null
          id?: string
          latitude?: number | null
          location_source?: string | null
          location_status?: string
          longitude?: number | null
          mapped_at?: string | null
          mapped_by?: string | null
          pin_id?: string | null
          pin_type?: string
          source_files?: Json
          status?: string | null
          supervisor_id?: string | null
          updated_at?: string
          uploaded_at?: string | null
          uploaded_by?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "houses_assigned_csw_id_fkey"
            columns: ["assigned_csw_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "houses_pin_id_fkey"
            columns: ["pin_id"]
            isOneToOne: false
            referencedRelation: "pins"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "houses_supervisor_id_fkey"
            columns: ["supervisor_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      import_batches: {
        Row: {
          assigned_to: string | null
          assigned_to_name: string | null
          conflicts: number
          created_at: string
          file_names: Json
          houses_added: number
          houses_updated: number
          id: string
          members_added: number
          members_merged: number
          merged_records: number
          new_fields: Json
          status: string
          supervisor_id: string | null
          total_rows: number
          unique_houses: number
          unmapped_houses: number
          updated_at: string
          uploaded_by: string
          uploaded_by_name: string | null
          uploaded_role: string | null
        }
        Insert: {
          assigned_to?: string | null
          assigned_to_name?: string | null
          conflicts?: number
          created_at?: string
          file_names?: Json
          houses_added?: number
          houses_updated?: number
          id?: string
          members_added?: number
          members_merged?: number
          merged_records?: number
          new_fields?: Json
          status?: string
          supervisor_id?: string | null
          total_rows?: number
          unique_houses?: number
          unmapped_houses?: number
          updated_at?: string
          uploaded_by: string
          uploaded_by_name?: string | null
          uploaded_role?: string | null
        }
        Update: {
          assigned_to?: string | null
          assigned_to_name?: string | null
          conflicts?: number
          created_at?: string
          file_names?: Json
          houses_added?: number
          houses_updated?: number
          id?: string
          members_added?: number
          members_merged?: number
          merged_records?: number
          new_fields?: Json
          status?: string
          supervisor_id?: string | null
          total_rows?: number
          unique_houses?: number
          unmapped_houses?: number
          updated_at?: string
          uploaded_by?: string
          uploaded_by_name?: string | null
          uploaded_role?: string | null
        }
        Relationships: []
      }
      import_conflicts: {
        Row: {
          batch_id: string | null
          created_at: string
          entity: string
          existing_value: string | null
          field: string
          house_id: string
          house_uuid: string | null
          id: string
          member_ref: string | null
          new_value: string | null
          resolved_at: string | null
          resolved_by: string | null
          source_file: string | null
          status: string
          updated_at: string
        }
        Insert: {
          batch_id?: string | null
          created_at?: string
          entity?: string
          existing_value?: string | null
          field: string
          house_id: string
          house_uuid?: string | null
          id?: string
          member_ref?: string | null
          new_value?: string | null
          resolved_at?: string | null
          resolved_by?: string | null
          source_file?: string | null
          status?: string
          updated_at?: string
        }
        Update: {
          batch_id?: string | null
          created_at?: string
          entity?: string
          existing_value?: string | null
          field?: string
          house_id?: string
          house_uuid?: string | null
          id?: string
          member_ref?: string | null
          new_value?: string | null
          resolved_at?: string | null
          resolved_by?: string | null
          source_file?: string | null
          status?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "import_conflicts_batch_id_fkey"
            columns: ["batch_id"]
            isOneToOne: false
            referencedRelation: "import_batches"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "import_conflicts_house_uuid_fkey"
            columns: ["house_uuid"]
            isOneToOne: false
            referencedRelation: "houses"
            referencedColumns: ["id"]
          },
        ]
      }
      login_attempts: {
        Row: {
          fail_count: number
          locked_until: string | null
          updated_at: string
          username: string
        }
        Insert: {
          fail_count?: number
          locked_until?: string | null
          updated_at?: string
          username: string
        }
        Update: {
          fail_count?: number
          locked_until?: string | null
          updated_at?: string
          username?: string
        }
        Relationships: []
      }
      pins: {
        Row: {
          accuracy: number | null
          created_at: string
          custom_type: string | null
          device_id: string | null
          device_time: string | null
          external_created_at: string | null
          house_id: string | null
          house_number: string | null
          house_uuid: string | null
          id: string
          import_key: string | null
          latitude: number
          longitude: number
          notes: string | null
          owner_name: string | null
          pin_type: string
          source: string
          surveyor: string | null
          updated_at: string
          user_id: string
          username: string
        }
        Insert: {
          accuracy?: number | null
          created_at?: string
          custom_type?: string | null
          device_id?: string | null
          device_time?: string | null
          external_created_at?: string | null
          house_id?: string | null
          house_number?: string | null
          house_uuid?: string | null
          id?: string
          import_key?: string | null
          latitude: number
          longitude: number
          notes?: string | null
          owner_name?: string | null
          pin_type: string
          source?: string
          surveyor?: string | null
          updated_at?: string
          user_id: string
          username: string
        }
        Update: {
          accuracy?: number | null
          created_at?: string
          custom_type?: string | null
          device_id?: string | null
          device_time?: string | null
          external_created_at?: string | null
          house_id?: string | null
          house_number?: string | null
          house_uuid?: string | null
          id?: string
          import_key?: string | null
          latitude?: number
          longitude?: number
          notes?: string | null
          owner_name?: string | null
          pin_type?: string
          source?: string
          surveyor?: string | null
          updated_at?: string
          user_id?: string
          username?: string
        }
        Relationships: [
          {
            foreignKeyName: "pins_house_uuid_fkey"
            columns: ["house_uuid"]
            isOneToOne: false
            referencedRelation: "houses"
            referencedColumns: ["id"]
          },
        ]
      }
      profiles: {
        Row: {
          avatar_url: string | null
          created_at: string
          email: string | null
          full_name: string | null
          id: string
          is_active: boolean
          phone: string | null
          updated_at: string
          username: string
        }
        Insert: {
          avatar_url?: string | null
          created_at?: string
          email?: string | null
          full_name?: string | null
          id: string
          is_active?: boolean
          phone?: string | null
          updated_at?: string
          username: string
        }
        Update: {
          avatar_url?: string | null
          created_at?: string
          email?: string | null
          full_name?: string | null
          id?: string
          is_active?: boolean
          phone?: string | null
          updated_at?: string
          username?: string
        }
        Relationships: []
      }
      team_memberships: {
        Row: {
          created_at: string
          csw_id: string
          id: string
          status: string
          supervisor_id: string
          updated_at: string
        }
        Insert: {
          created_at?: string
          csw_id: string
          id?: string
          status?: string
          supervisor_id: string
          updated_at?: string
        }
        Update: {
          created_at?: string
          csw_id?: string
          id?: string
          status?: string
          supervisor_id?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "team_memberships_csw_id_fkey"
            columns: ["csw_id"]
            isOneToOne: true
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "team_memberships_supervisor_id_fkey"
            columns: ["supervisor_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      user_roles: {
        Row: {
          id: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Insert: {
          id?: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Update: {
          id?: string
          role?: Database["public"]["Enums"]["app_role"]
          user_id?: string
        }
        Relationships: []
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      can_access_house: {
        Args: { _house: string; _user: string }
        Returns: boolean
      }
      has_role: {
        Args: {
          _role: Database["public"]["Enums"]["app_role"]
          _user_id: string
        }
        Returns: boolean
      }
      is_admin_like: { Args: { _user_id: string }; Returns: boolean }
      is_supervisor_of: {
        Args: { _csw_id: string; _supervisor_id: string }
        Returns: boolean
      }
    }
    Enums: {
      app_role: "admin" | "survey_user" | "super_admin" | "supervisor"
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {
      app_role: ["admin", "survey_user", "super_admin", "supervisor"],
    },
  },
} as const
